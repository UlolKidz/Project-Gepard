/* GEPARD V5.0 — dashboard logic over Socket.IO (WebUI Brick, port 7000).
   Verified pattern: io("http://"+location.host), socket.emit(), socket.on().
   Telemetry is PUSHED from Python (no browser polling). */

const socket = io("http://" + window.location.host);

/* ---- connection status ---- */
socket.on("connect", () => {
  document.getElementById("linkPill").textContent = "● LINK OK";
  document.getElementById("linkPill").style.color = "#39ff9e";
  socket.emit("hello", {});                 // ask server for mode + camera URL
});
socket.on("disconnect", () => {
  document.getElementById("linkPill").textContent = "● LINK LOST";
  document.getElementById("linkPill").style.color = "#ff4d4d";
});

/* ---- one-time hello reply: mode + camera stream ---- */
socket.on("hello", (d) => {
  if (d.mode) setModePill(d.mode);
  if (d.camera) setCamera(d.camera);
});
socket.on("mode",  (d) => setModePill(d.mode));
socket.on("estop", (d) => {
  estopped = !!d.estop;
  document.getElementById("estopBtn").textContent = estopped ? "▶ CLEAR E-STOP" : "■ E-STOP";
});

function setModePill(mode){
  document.getElementById("modePill").textContent = "MODE: " + mode;
  document.querySelectorAll(".modebar button").forEach(x =>
    x.classList.toggle("active", x.dataset.mode === mode));
}
function setCamera(url){
  const a = document.getElementById("camFeed"); if (a && !a.src) a.src = url;
  const b = document.getElementById("camFeed2"); if (b && !b.src) b.src = url;
  document.getElementById("camNote").textContent = url;
}

/* ---- tabs ---- */
document.querySelectorAll(".tab").forEach(t => {
  t.onclick = () => {
    document.querySelectorAll(".tab").forEach(x => x.classList.remove("active"));
    document.querySelectorAll(".panel").forEach(x => x.classList.remove("active"));
    t.classList.add("active");
    document.getElementById(t.dataset.tab).classList.add("active");
  };
});

/* ---- mode switch (emit) ---- */
document.querySelectorAll(".modebar button").forEach(b => {
  b.onclick = () => socket.emit("mode", { mode: b.dataset.mode });
});

/* ---- e-stop (emit, latching) ---- */
let estopped = false;
document.getElementById("estopBtn").onclick = () => {
  estopped = !estopped;
  socket.emit("estop", { on: estopped });
};

/* ---- manual drive (emit) ---- */
const drive = cmd => socket.emit("drive", { cmd });
document.querySelectorAll("[data-drive]").forEach(b => {
  b.onmousedown = () => drive(b.dataset.drive);
  b.onmouseup   = () => drive("S");
});
const KEYMAP = { w:"F", a:"L", s:"B", d:"R", x:"S", " ":"S" };
document.addEventListener("keydown", e => {
  const c = KEYMAP[e.key.toLowerCase()];
  if (c && !e.repeat) drive(c);
});
document.addEventListener("keyup", e => {
  if (KEYMAP[e.key.toLowerCase()]) drive("S");
});

/* ---- pan/tilt sliders (emit, throttled to ~15/sec) ---- */
const panSlider = document.getElementById("panSlider");
const tiltSlider = document.getElementById("tiltSlider");
let lastPanTiltSend = 0;
function sendPanTilt(){
  const now = Date.now();
  if (now - lastPanTiltSend < 66) return;   // ~15 msgs/sec max
  lastPanTiltSend = now;
  socket.emit("pantilt", { pan: Number(panSlider.value), tilt: Number(tiltSlider.value) });
}
panSlider.oninput = () => {
  document.getElementById("panVal").textContent = panSlider.value + "°";
  sendPanTilt();
};
tiltSlider.oninput = () => {
  document.getElementById("tiltVal").textContent = tiltSlider.value + "°";
  sendPanTilt();
};

/* ---- test bench (emit -> server replies to this client) ---- */
document.querySelectorAll("[data-test]").forEach(b => {
  b.onclick = () => socket.emit("test", { module: b.dataset.test });
});
socket.on("test_result", (d) => {
  document.getElementById("testOut").textContent = `${d.module}  ->  ${d.result}`;
});

/* ---- AI cognition + console (pushed) ---- */
socket.on("cognition", (d) => {
  document.getElementById("cognition").textContent = `${d.perception}  ->  ${d.action}`;
});
socket.on("console", (d) => {
  const cons = document.getElementById("console");
  const div = document.createElement("div");
  div.textContent = d.line;
  cons.appendChild(div);
  while (cons.childElementCount > 60) cons.removeChild(cons.firstChild);
  cons.scrollTop = cons.scrollHeight;
});

/* ---- radar ---- */
const radar = document.getElementById("radar");
const rctx = radar.getContext("2d");
let sweep = 0;
function drawRadar(distCm) {
  const w = radar.width, cx = w/2, cy = w/2, R = w/2 - 6;
  rctx.clearRect(0,0,w,w);
  rctx.strokeStyle = "#1c3a2e";
  for (let i=1;i<=3;i++){ rctx.beginPath(); rctx.arc(cx,cy,R*i/3,0,Math.PI*2); rctx.stroke(); }
  rctx.beginPath(); rctx.moveTo(cx,cy); rctx.lineTo(cx,cy-R); rctx.stroke();
  sweep = (sweep + 0.08) % (Math.PI*2);
  rctx.strokeStyle = "#39ff9e";
  rctx.beginPath(); rctx.moveTo(cx,cy);
  rctx.lineTo(cx + R*Math.sin(sweep), cy - R*Math.cos(sweep)); rctx.stroke();
  if (distCm > 0 && distCm < 100) {
    const rr = R * (distCm/100);
    rctx.fillStyle = distCm < 20 ? "#ff4d4d" : "#ffb020";
    rctx.beginPath(); rctx.arc(cx, cy - rr, 5, 0, Math.PI*2); rctx.fill();
  }
}
setInterval(() => drawRadar(lastDist), 60);   // animate sweep smoothly
let lastDist = -1;

/* ---- sensor list ---- */
const SENSORS = [
  ["Ultrasonic","ultrasonic_valid"], ["Encoders","encoders_valid"],
  ["Cliff L","ir_valid"], ["Cliff R","ir_valid"], ["Rear IR","ir_valid"],
  ["INA226","ina226_valid"], ["MPU6050","mpu6050_valid"],
];
let lastTicks = null, lastT = null;
const fmt = v => (v===undefined||v===null) ? "--" : Number(v).toFixed(2);

/* ---- telemetry (PUSHED over WebSocket, no polling) ---- */
socket.on("telemetry", (t) => {
  if (t.mode) setModePill(t.mode);

  lastDist = t.ultrasonic_valid ? Number(t.ultrasonic_cm) : -1;
  document.getElementById("distVal").textContent =
    (t.ultrasonic_valid ? `${Number(t.ultrasonic_cm).toFixed(0)} cm` : "no echo");
  document.getElementById("axVal").textContent = fmt(t.accel_x);
  document.getElementById("ayVal").textContent = fmt(t.accel_y);
  document.getElementById("azVal").textContent = fmt(t.accel_z);
  document.getElementById("voltVal").textContent =
    (t.ina226_valid ? `${Number(t.bus_voltage_v).toFixed(2)} V` : "-- V");

  if (t.ina226_valid) {
    const pct = Math.max(0, Math.min(100, ((t.bus_voltage_v - 9) / 3.6) * 100));
    document.getElementById("battFill").style.width = pct + "%";
  }

  const now = Date.now();
  const ticks = (t.enc_left_ticks||0) + (t.enc_right_ticks||0);
  if (lastTicks !== null) {
    const rate = (ticks - lastTicks) / ((now - lastT)/1000 || 1);
    document.getElementById("speedVal").textContent = rate.toFixed(1) + " t/s";
  }
  lastTicks = ticks; lastT = now;

  document.getElementById("sensorList").innerHTML = SENSORS.map(([label,key]) => {
    const ok = t[key] ? "ok" : "bad";
    return `<li>${label}<span class="dot ${ok}"></span></li>`;
  }).join("");

  const pirEl = document.getElementById("pirVal");
  const motion = !!t.pir_motion;
  pirEl.textContent = motion ? "++ MOTION ++" : "CLEAR";
  pirEl.style.color = motion ? "#ff4d4d" : "#39ff9e";
});
