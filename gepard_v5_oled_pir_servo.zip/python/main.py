"""
============================================================================
GEPARD V5.0  --  UNO Q LINUX APP  (python/main.py)   Python 3.13 / Linux MPU
============================================================================
Rebuilt to the OFFICIAL Arduino App Bricks patterns, verified against:
  * DeepWiki "Core Platform Architecture" / "Bridge Communication System" /
    "App Structure and Configuration" (arduino/app-bricks-examples)
  * newbiely.com UNO Q "Web Server" and "WebSocket" tutorials

WHAT THIS DOES
  * Hosts the dashboard via the WebUI Brick at http://<UNO_Q_IP>:7000
    (HTTP file server + Socket.IO WebSocket server, both on 7000).
  * POLLS the MCU:   Bridge.call("get_telemetry")   -- Linux always calls;
    Bridge.call blocks until the MCU provider returns, and returns the value
    DIRECTLY (no .result() unwrap needed on the Python side).
  * PUSHES telemetry to every browser over WebSocket with
    ui.send_message("telemetry", data)  -- NO browser polling.
  * RECEIVES browser events with ui.on_message(event, handler); each handler
    gets (client, data). Commands are forwarded to the MCU via Bridge.call.
  * Logs telemetry to CSV for the LabVIEW / NI sponsor deliverable.
  * Runs the decision layer (rule-based today; 1-line swap to a local LLM).

KEY API SIGNATURES (verified, do not "improve" back to guesses):
  Bridge.call("fn", arg)                 -> synchronous, returns value
  ui.on_message("event", handler)        -> handler(client, data)
  ui.send_message("event", payload)      -> broadcast to all clients
  ui.send_message("event", payload, cli) -> reply to one client
  ui.expose_api(...)                     -> for plain HTTP JSON (kept as bonus)
============================================================================
"""

import time
import csv
import threading

from arduino.app_utils import App, Bridge
from arduino.app_bricks.web_ui import WebUI

import llm_brain   # perception + decide()  (the LLM swap point)

# ---------------------------------------------------------------------------
# CONFIG
# ---------------------------------------------------------------------------
CAMERA_STREAM_URL     = "http://192.168.1.60:81/stream"  # ESP32-S3-CAM MJPEG
CSV_PATH              = "gepard_telemetry.csv"
PUSH_INTERVAL_SEC     = 0.2      # 5 Hz telemetry poll + WebSocket push
DECISION_INTERVAL_SEC = 0.6      # ROAM: how often the brain chooses an action

VALID_MODES = {"MANUAL", "ROAM", "SENTINEL"}

# Must match the CSV string order the MCU builds in get_telemetry().
FIELD_ORDER = [
    "ultrasonic_cm", "ultrasonic_valid",
    "enc_left_ticks", "enc_right_ticks", "encoders_valid",
    "cliff_left", "cliff_right", "rear_ir", "ir_valid",
    "bus_voltage_v", "ina226_valid",
    "accel_x", "accel_y", "accel_z", "mpu6050_valid",
    "current_command", "obstacle_override", "estop",
    "pir_motion",
]

# ---------------------------------------------------------------------------
# SHARED STATE
# ---------------------------------------------------------------------------
state_lock   = threading.Lock()
current_mode = "MANUAL"
latest       = {}
event_log    = []
_last_decision_at = 0.0

def log_event(msg):
    line = f"[{time.strftime('%H:%M:%S')}] {msg}"
    with state_lock:
        event_log.append(line)
        if len(event_log) > 200:
            del event_log[:len(event_log) - 200]
    print(line)
    # push console lines live to the HUD
    try:
        ui.send_message("console", {"line": line})
    except Exception:
        pass

# ---------------------------------------------------------------------------
# CSV
# ---------------------------------------------------------------------------
_csv_file = open(CSV_PATH, "a", newline="")
_csv_writer = csv.writer(_csv_file)
if _csv_file.tell() == 0:
    _csv_writer.writerow(["timestamp", "mode"] + FIELD_ORDER)
    _csv_file.flush()

# ---------------------------------------------------------------------------
# TELEMETRY PARSE
# ---------------------------------------------------------------------------
def parse_telemetry(csv_string):
    parts = str(csv_string).split(",")
    if len(parts) != len(FIELD_ORDER):
        log_event(f"telemetry field count mismatch: got {len(parts)}")
        return None
    rec = {}
    for key, val in zip(FIELD_ORDER, parts):
        if key == "current_command":
            rec[key] = val
        else:
            try:
                rec[key] = float(val) if "." in val else int(val)
            except ValueError:
                rec[key] = val
    return rec

# ---------------------------------------------------------------------------
# WEBUI BRICK  (serves assets/ + Socket.IO on :7000 automatically)
# ---------------------------------------------------------------------------
ui = WebUI()

# ---- incoming WebSocket events from the browser: handler(client, data) ----
def on_drive(client, data):
    cmd = str((data or {}).get("cmd", "S")).upper()[:1]
    Bridge.call("set_drive", cmd)
    log_event(f"drive {cmd}")

def on_mode(client, data):
    global current_mode
    mode = str((data or {}).get("mode", "")).upper()
    if mode not in VALID_MODES:
        ui.send_message("ack", {"ok": False, "error": "invalid mode"}, client)
        return
    with state_lock:
        current_mode = mode
    if mode == "MANUAL":
        Bridge.call("set_drive", "S")   # land stopped
    log_event(f"MODE -> {mode}")
    ui.send_message("mode", {"mode": mode})      # broadcast new mode to all

def on_test(client, data):
    module = str((data or {}).get("module", ""))
    result = Bridge.call("test_module", module)
    log_event(f"TEST {module}: {result}")
    ui.send_message("test_result", {"module": module, "result": result}, client)

def on_estop(client, data):
    on = 1 if (data or {}).get("on") else 0
    Bridge.call("set_estop", on)
    log_event(f"E-STOP {'ON' if on else 'OFF'}")
    ui.send_message("estop", {"estop": bool(on)})  # broadcast state to all

def on_pantilt(client, data):
    pan  = int((data or {}).get("pan", 90))
    tilt = int((data or {}).get("tilt", 90))
    pan  = max(0, min(180, pan))
    tilt = max(0, min(180, tilt))
    Bridge.call("set_pantilt", f"{pan},{tilt}")

def on_hello(client, data):
    # New browser connected -> send it the current mode + camera URL once.
    with state_lock:
        mode = current_mode
    ui.send_message("hello", {"mode": mode, "camera": CAMERA_STREAM_URL}, client)

ui.on_message("drive",   on_drive)
ui.on_message("mode",    on_mode)
ui.on_message("test",    on_test)
ui.on_message("estop",   on_estop)
ui.on_message("pantilt", on_pantilt)
ui.on_message("hello",   on_hello)

# ---- optional plain HTTP JSON endpoint (kept as a bonus / debugging aid) ----
def api_telemetry(request):
    with state_lock:
        return {"mode": current_mode, "telemetry": dict(latest),
                "camera": CAMERA_STREAM_URL}
ui.expose_api("GET", "/api/telemetry", api_telemetry)

# ---------------------------------------------------------------------------
# MAIN LOOP  (poll MCU -> push over WebSocket -> ROAM decision)
# App.run(user_loop=...) calls this repeatedly; we pace it with sleep.
# ---------------------------------------------------------------------------
def loop():
    global latest, _last_decision_at
    # 1) poll the MCU (Linux always calls; value returns directly)
    try:
        csv_string = Bridge.call("get_telemetry")
        rec = parse_telemetry(csv_string) if csv_string else None
    except Exception as e:
        log_event(f"poll error: {e}")
        rec = None

    if rec:
        with state_lock:
            latest = rec
            mode = current_mode
        # 2) log + push to every browser over WebSocket (no polling)
        _csv_writer.writerow([time.time(), mode] + [rec[f] for f in FIELD_ORDER])
        _csv_file.flush()
        rec_out = dict(rec)
        rec_out["mode"] = mode
        ui.send_message("telemetry", rec_out)

        # 3) ROAM autonomy (rate-limited)
        now = time.time()
        if mode == "ROAM" and (now - _last_decision_at) >= DECISION_INTERVAL_SEC:
            _last_decision_at = now
            perception = llm_brain.summarize_perception(rec)
            action = llm_brain.decide(perception, goal="explore safely, avoid edges")
            Bridge.call("set_drive", llm_brain.action_to_drive(action))
            log_event(f"ROAM: {perception[:44]} -> {action}")
            ui.send_message("cognition", {"perception": perception, "action": action})

    time.sleep(PUSH_INTERVAL_SEC)

# ---------------------------------------------------------------------------
# START
# ---------------------------------------------------------------------------
log_event("GEPARD V5.0 Linux app starting (WebUI :7000, WebSocket push).")
App.run(user_loop=loop)
