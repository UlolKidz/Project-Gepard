"""
============================================================================
GEPARD V5.0  --  llm_brain.py   THE BRAIN SOCKET  (runs on UNO Q Linux 3.13)
============================================================================
  1. PERCEPTION  -> summarize_perception(): all sensor feeds -> one English line
  2. DECISION    -> decide(): rule-based today; 1-line swap to a local LLM
  3. MEMORY/MAP  -> MEMORY_SCHEMA: the STRUCTURE for future 2D SLAM map, named
     places, and face identities (structure only; not implemented tonight)
============================================================================
"""

# ---------------------------------------------------------------------------
# 1. PERCEPTION LAYER
# ---------------------------------------------------------------------------
def summarize_perception(t):
    ultra = t.get("ultrasonic_cm", -1)
    ultra_ok = t.get("ultrasonic_valid", 0)
    cliff_l = t.get("cliff_left", 1)
    cliff_r = t.get("cliff_right", 1)
    rear    = t.get("rear_ir", 1)
    volts   = t.get("bus_voltage_v", -1)
    az      = t.get("accel_z", 1.0)

    edge = []
    if cliff_l == 0: edge.append("left")
    if cliff_r == 0: edge.append("right")
    edge_phrase = ("edge on " + "/".join(edge)) if edge else "no edge"

    if not ultra_ok or ultra < 0:
        path = "distance sensor invalid"
    elif ultra < 15:
        path = f"obstacle VERY close ahead ({ultra:.0f} cm)"
    elif ultra < 30:
        path = f"obstacle ahead ({ultra:.0f} cm)"
    else:
        path = f"path ahead clear ({ultra:.0f} cm)"

    tilt = "level" if 0.7 < az < 1.3 else "TILTED"
    batt = f"battery {volts:.1f}V" if volts >= 0 else "battery n/a"
    rearp = "clear behind" if rear else "object behind"
    return f"{path}. {edge_phrase}. {tilt}. {batt}. {rearp}."

# ---------------------------------------------------------------------------
# 2. DECISION LAYER  -- THE ONE SWAP POINT
# ---------------------------------------------------------------------------
def decide(perception, goal="explore safely"):
    # ---- rule-based policy (works today, transparent) ----
    p = perception.lower()
    if "edge" in p and "no edge" not in p:
        return "BACK"
    if "very close" in p or "obstacle ahead" in p:
        return "RIGHT"
    if "invalid" in p or "tilted" in p:
        return "STOP"
    return "FORWARD"

    # ---- to marry the LLM: comment the block above, uncomment below ----
    # return decide_with_llm(perception, goal)

def action_to_drive(action):
    return {"FORWARD": "F", "BACK": "B", "LEFT": "L",
            "RIGHT": "R", "STOP": "S"}.get(action, "S")

# ---------------------------------------------------------------------------
# LOCAL LLM ADAPTER  (Ollama, Llama 3.2 3B on the laptop GPU)
# ---------------------------------------------------------------------------
_SYSTEM_PROMPT = (
    "You are the driving brain of a small ground rover. You are given a "
    "one-line perception summary of the rover's sensors. Reply with EXACTLY "
    "one word from this menu and nothing else: FORWARD, LEFT, RIGHT, BACK, "
    "STOP. Never drive toward an edge or a very close obstacle."
)

def decide_with_llm(perception, goal):
    try:
        import ollama
        client = ollama.Client(host="http://192.168.1.100:11434")  # laptop IP
        resp = client.chat(model="llama3.2:3b", messages=[
            {"role": "system", "content": _SYSTEM_PROMPT},
            {"role": "user",   "content": f"Goal: {goal}\nSensors: {perception}"},
        ])
        word = resp["message"]["content"].strip().upper().split()[0]
        return word if word in {"FORWARD","LEFT","RIGHT","BACK","STOP"} else "STOP"
    except Exception:
        return decide(perception, goal)

def decide_with_gemini(perception, goal):
    """DELIBERATE STUB. Text-only, billing on, NEVER camera frames."""
    raise NotImplementedError("Gemini path intentionally left as a stub.")

# ===========================================================================
# 3. MEMORY / MAP DATA SCHEMA  (STRUCTURE ONLY)
# ===========================================================================
MEMORY_SCHEMA = {
    "map": {
        "resolution_cm": 5,
        "origin": {"x": 0, "y": 0},
        "grid": [],                 # list[list[int]] 0 unknown/1 free/2 wall
        "pose": {"x_cm": 0, "y_cm": 0, "heading_deg": 0},
    },
    "places": [],   # {"name":"kitchen","x_cm":120,"y_cm":-60,"created":0.0}
    "faces":  [],   # {"name":"hein","encoding_ref":"...","role":"owner"}
    "events": [],   # {"ts":0.0,"type":"motion","snapshot":"..."}
}

def load_memory(path="gepard_memory.json"):
    import json, os
    if os.path.exists(path):
        with open(path) as f:
            return json.load(f)
    return dict(MEMORY_SCHEMA)

def save_memory(mem, path="gepard_memory.json"):
    import json
    with open(path, "w") as f:
        json.dump(mem, f, indent=2)


if __name__ == "__main__":
    for s in [
        {"ultrasonic_cm":80,"ultrasonic_valid":1,"cliff_left":1,"cliff_right":1,
         "rear_ir":1,"bus_voltage_v":12.3,"accel_z":1.0},
        {"ultrasonic_cm":12,"ultrasonic_valid":1,"cliff_left":1,"cliff_right":1,
         "rear_ir":1,"bus_voltage_v":12.1,"accel_z":1.0},
        {"ultrasonic_cm":60,"ultrasonic_valid":1,"cliff_left":0,"cliff_right":1,
         "rear_ir":1,"bus_voltage_v":12.0,"accel_z":1.0},
    ]:
        per = summarize_perception(s)
        print(f"PERCEPTION: {per}\n   -> {decide(per)}\n")
