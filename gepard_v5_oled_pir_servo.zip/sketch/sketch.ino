/*
 * ============================================================================
 * GEPARD V5.0  --  MCU SKETCH  (sketch/sketch.ino)   UNO Q microcontroller
 * Runs on Zephyr RTOS (C++). THE SPINE / REFLEXES: reads sensors, drives
 * motors, exposes hardware to Linux over the Bridge.
 * ============================================================================
 * REGISTRATION RULE (verified against the official Bridge API Reference):
 *
 *   Bridge.provide_safe(name, fn)  -> runs the callback in the loop() context.
 *       REQUIRED whenever the callback touches standard Arduino hardware APIs
 *       (digitalWrite / analogWrite / Serial / I2C / servo), to prevent
 *       concurrency crashes. Used here for everything that DRIVES or READS
 *       hardware live: set_drive, set_nudge, set_estop, test_module,
 *       set_pantilt
 *
 *   Bridge.provide(name, fn)       -> runs the callback in the high-priority
 *       background RPC thread. Must stay SHORT and THREAD-SAFE.
 *       DANGER: never call Bridge.call() or Monitor.print() inside it.
 *       Used here ONLY for get_telemetry, which is a PURE read-and-return:
 *       it locks, copies cached sensor variables into a string, unlocks, and
 *       returns. It performs NO hardware access and NO other Bridge calls.
 *
 *   >>> Sensor SAMPLING (pulseIn, I2C, digitalRead) happens in loop() (safe
 *       hardware context) and is written to mutex-protected cache variables.
 *       get_telemetry only ever reads that cache. This keeps get_telemetry
 *       short + hardware-free as provide() requires, and moves the blocking
 *       25 ms ultrasonic ping off the RPC thread. <<<
 *
 * LOCKED DESIGN: NO obstacle override in MANUAL. The only drive override is
 * the Linux-controlled e-stop (set_estop).
 *
 * >>> HARDWARE-SAFETY RULE FOR THE OLED (read this before touching it) <<<
 * The most common Adafruit SSD1306 example code does this on init failure:
 *     if(!display.begin(...)) { Serial.println("failed"); for(;;); }
 * DO NOT DO THAT HERE. An infinite for(;;) in setup() would freeze the WHOLE
 * MCU before Bridge.begin() even runs -- that's exactly the kind of bug that
 * caused the full get_telemetry/set_drive timeout earlier tonight. Instead,
 * we set an `oledOK` flag: if the screen doesn't answer, we just skip drawing
 * to it forever and everything else (motors, telemetry, Bridge) keeps working
 * completely normally.
 *
 * TONIGHT'S WIRING NOTE (per the master runbook):
 *   - MPU6050 is intentionally NOT installed tonight -> "no i2c" is expected.
 *   - The PIR sensor is hijacking the old PIN_CLIFF_R (D10) slot, since the
 *     downward cliff sensors are not installed tonight either. That pin is
 *     now dedicated to PIR ONLY -- it no longer reads a cliff sensor.
 *   - INA226 lives at 0x45 now (solder-bridge workaround), not the old 0x40.
 * ============================================================================
 */

#include <Arduino.h>
#include <Wire.h>
#include "Arduino_RouterBridge.h"

// If Servo.h isn't found at compile time (rare -- most cores bundle it the
// same way Wire.h is bundled), add a "Servo" line under sketch/sketch.yaml's
// libraries: section. Don't add it preemptively -- see the note up there
// about Arduino_RouterBridge migration hangs on already-bundled libraries.
#include <Servo.h>

// OLED libraries -- these are NOT bundled with any core, they must be listed
// under sketch/sketch.yaml's libraries: section (already done below).
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

// ---- PIN MAP (Updated to match your actual wiring) ----
#define PIN_STBY    13
#define PIN_PWMA    5
#define PIN_AIN1    4
#define PIN_AIN2    7
#define PIN_PWMB    6
#define PIN_BIN1    8
#define PIN_BIN2    12
#define PIN_TRIG    A0
#define PIN_ECHO    A1
#define PIN_ENC_L   2      // INTERRUPT
#define PIN_ENC_R   3      // INTERRUPT
#define PIN_CLIFF_L 9      // not installed tonight -- floating pull-up, harmless
#define PIN_PIR     10     // was PIN_CLIFF_R -- PIR now lives on this exact pin
#define PIN_REAR_IR 11     // not installed tonight -- floating pull-up, harmless
#define PIN_SERVO_PAN  A2  // pan (horizontal) MG90S signal
#define PIN_SERVO_TILT A3  // tilt (vertical) MG90S signal
#define INA226_ADDR  0x45  // was 0x40 -- changed due to A0/A1 solder bridge to VCC
#define MPU6050_ADDR 0x68
#define OLED_ADDR    0x3C
#define OLED_W       128
#define OLED_H       64

// ---- motion/timing constants (PLACEHOLDER -- tune to your motors) ----
#define DRIVE_SPEED        200   // PWM 0-255 for forward/back
#define TURN_SPEED         160   // PWM 0-255 for in-place turns
#define SAMPLE_INTERVAL_MS 20    // how often loop() samples sensors, in ms
#define OLED_INTERVAL_MS   200   // how often the OLED redraws (I2C isn't free)

// ---- mutex protects the cache + command/estop shared with the RPC thread ----
K_MUTEX_DEFINE(state_mtx);
static inline void lockState()   { k_mutex_lock(&state_mtx, K_FOREVER); }
static inline void unlockState() { k_mutex_unlock(&state_mtx); }

// ISR-updated raw counters
volatile unsigned long encLeftTicks = 0, encRightTicks = 0;

// ---- CACHED sensor snapshot (written by loop(), read by get_telemetry) ----
float         c_ultra = -1;      bool c_ultraValid = false;
unsigned long c_encL = 0, c_encR = 0;
int           c_cliffL = 1, c_cliffR = 1, c_rearIR = 1;  // not installed -> always 1 (harmless)
int           c_pir = 0;                                 // 0 = clear, 1 = motion
float         c_busV = -1;       bool c_inaValid = false;
float         c_ax = 0, c_ay = 0, c_az = 0;  bool c_mpuValid = false;

// ---- command state (written by provide_safe callbacks, read by telemetry) --
char          currentCommand = 'S';
bool          estop = false;
unsigned long nudgeStopAt = 0;

// ---- servo state (written by set_pantilt, read only by OLED/loop) ----
int currentPan = 90, currentTilt = 90;

void isrEncLeft()  { encLeftTicks++; }
void isrEncRight() { encRightTicks++; }

// ---- hardware objects ----
Servo servoPan, servoTilt;
Adafruit_SSD1306 oled(OLED_W, OLED_H, &Wire, -1);
bool oledOK = false;   // see safety note at top of file -- NEVER hang on this

// ---- motor primitives (only ever called in loop() context) ----
void motorLeft(int dir, int spd){
  digitalWrite(PIN_AIN1, dir>0?HIGH:LOW); digitalWrite(PIN_AIN2, dir<0?HIGH:LOW);
  analogWrite(PIN_PWMA, dir==0?0:spd);
}
void motorRight(int dir, int spd){
  digitalWrite(PIN_BIN1, dir>0?HIGH:LOW); digitalWrite(PIN_BIN2, dir<0?HIGH:LOW);
  analogWrite(PIN_PWMB, dir==0?0:spd);
}
void driveStop()   { motorLeft(0,0);  motorRight(0,0); }
void driveForward(){ motorLeft(+1,DRIVE_SPEED); motorRight(+1,DRIVE_SPEED); }
void driveBack()   { motorLeft(-1,DRIVE_SPEED); motorRight(-1,DRIVE_SPEED); }
void driveLeft()   { motorLeft(-1,TURN_SPEED);  motorRight(+1,TURN_SPEED);  }
void driveRight()  { motorLeft(+1,TURN_SPEED);  motorRight(-1,TURN_SPEED);  }

// Apply a drive char. Runs in loop() context (via provide_safe or loop()).
void applyCommand(char c){
  lockState(); currentCommand = c; bool es = estop; unlockState();
  if (es){ driveStop(); return; }      // Linux e-stop is the only override
  switch(c){
    case 'F': driveForward(); break;
    case 'B': driveBack();    break;
    case 'L': driveLeft();    break;
    case 'R': driveRight();   break;
    default:  driveStop();    break;
  }
}

// ---- raw sensor reads (ONLY called from loop() -- safe hardware context) ----
float readUltrasonicCm(){
  digitalWrite(PIN_TRIG,LOW); delayMicroseconds(2);
  digitalWrite(PIN_TRIG,HIGH); delayMicroseconds(10); digitalWrite(PIN_TRIG,LOW);
  unsigned long dur = pulseIn(PIN_ECHO,HIGH,25000UL);
  if (dur==0) return -1.0;
  return (dur*0.0343f)/2.0f;
}
float readBusVoltage(){
  Wire.beginTransmission(INA226_ADDR); Wire.write(0x02);
  if (Wire.endTransmission(false)!=0) return -1.0;
  Wire.requestFrom(INA226_ADDR,2);
  if (Wire.available()<2) return -1.0;
  uint16_t raw = (Wire.read()<<8)|Wire.read();
  return raw*0.00125f;
}
bool readAccel(float &ax,float &ay,float &az){
  Wire.beginTransmission(MPU6050_ADDR); Wire.write(0x3B);
  if (Wire.endTransmission(false)!=0) return false;
  Wire.requestFrom(MPU6050_ADDR,6);
  if (Wire.available()<6) return false;
  int16_t rx=(Wire.read()<<8)|Wire.read();
  int16_t ry=(Wire.read()<<8)|Wire.read();
  int16_t rz=(Wire.read()<<8)|Wire.read();
  ax=rx/16384.0f; ay=ry/16384.0f; az=rz/16384.0f;
  return true;
}

// Sample every sensor in loop() context and write the mutex-protected cache.
void sampleSensors(){
  float ultra = readUltrasonicCm();  bool ultraValid = ultra>=0;
  int pir = digitalRead(PIN_PIR);
  float busV = readBusVoltage();     bool inaValid = busV>=0;
  float ax=0,ay=0,az=0;              bool mpuValid = readAccel(ax,ay,az);
  noInterrupts(); unsigned long l=encLeftTicks, r=encRightTicks; interrupts();

  lockState();
  c_ultra=ultra; c_ultraValid=ultraValid;
  c_encL=l; c_encR=r;
  c_pir=pir;                                  // cliffL/cliffR/rearIR stay 1 (not installed)
  c_busV=busV; c_inaValid=inaValid;
  c_ax=ax; c_ay=ay; c_az=az; c_mpuValid=mpuValid;
  unlockState();
}

// Redraw the OLED from the cached snapshot. Called on its own slower cadence
// from loop() -- never called from the RPC thread, never allowed to hang.
void updateOLED(){
  if(!oledOK) return;   // screen missing/failed at boot -- silently skip forever

  lockState();
  float ultra=c_ultra;   bool uv=c_ultraValid;
  float busV=c_busV;     bool iv=c_inaValid;
  int pir=c_pir;
  unlockState();

  oled.clearDisplay();
  oled.setTextSize(1);
  oled.setTextColor(SSD1306_WHITE);
  oled.setCursor(0,0);
  oled.println("== GEPARD V5.0 ==");

  oled.setCursor(0,16);
  if(iv) { oled.print("PWR: "); oled.print(busV,2); oled.println(" V"); }
  else     oled.println("PWR: I2C ERROR");

  oled.setCursor(0,28);
  if(uv) { oled.print("DIST: "); oled.print(ultra,1); oled.println(" cm"); }
  else     oled.println("DIST: no echo");

  oled.setCursor(0,44);
  oled.println(pir ? "++ MOTION ++" : "PIR: CLEAR");

  oled.display();
}

// ============================================================================
// BRIDGE PROVIDER (background RPC thread) -- PURE READ, NO HARDWARE, NO Bridge
// call/Monitor.print inside. Just locks the cache, formats it, returns it.
// Registered with Bridge.provide().
// ============================================================================
String get_telemetry(){
  lockState();
  float ultra=c_ultra;      bool uv=c_ultraValid;
  unsigned long l=c_encL,r=c_encR;
  int cl=c_cliffL,cr=c_cliffR,ri=c_rearIR;
  float busV=c_busV;        bool iv=c_inaValid;
  float ax=c_ax,ay=c_ay,az=c_az; bool mv=c_mpuValid;
  char cmd=currentCommand;  bool es=estop;
  int pir=c_pir;
  unlockState();

  String s="";
  s+=String(ultra,1)+","; s+=String(uv?1:0)+",";
  s+=String(l)+","; s+=String(r)+","; s+="1,";                 // encoders_valid
  s+=String(cl)+","; s+=String(cr)+","; s+=String(ri)+","; s+="1,"; // ir_valid
  s+=String(busV,3)+","; s+=String(iv?1:0)+",";
  s+=String(ax,3)+","+String(ay,3)+","+String(az,3)+","; s+=String(mv?1:0)+",";
  s+=String(cmd)+","; s+="0,";                                 // obstacle_override ALWAYS 0
  s+=String(es?1:0)+",";
  s+=String(pir);                                              // NEW: pir_motion (0/1)
  return s;
}

// ============================================================================
// BRIDGE PROVIDERS (loop() context) -- touch hardware -> provide_safe REQUIRED
// ============================================================================
String set_drive(String cmd){
  if(cmd.length()>0) applyCommand(cmd.charAt(0));
  return "ok";
}

String set_nudge(String dir,int ms){
  if(dir.length()>0) applyCommand(dir.charAt(0));
  lockState(); nudgeStopAt = millis()+(unsigned long)ms; unlockState();
  return "ok";
}

// Expects "pan,tilt" e.g. "90,45". Clamped to 0-180. Touches servo hardware
// -> MUST be provide_safe (loop() context), same rule as motors.
String set_pantilt(String args){
  int comma = args.indexOf(',');
  if(comma < 0) return "bad args";
  int pan  = args.substring(0, comma).toInt();
  int tilt = args.substring(comma+1).toInt();
  pan  = constrain(pan, 0, 180);
  tilt = constrain(tilt, 0, 180);
  servoPan.write(pan);
  servoTilt.write(tilt);
  currentPan = pan; currentTilt = tilt;
  return "ok";
}

String test_module(String name){
  if(name=="motors"){ driveForward(); delay(400); driveStop();
                      lockState(); currentCommand='S'; unlockState();
                      return "motors spun"; }
  if(name=="sonar")  return String(readUltrasonicCm(),1)+" cm";
  if(name=="ina226") return String(readBusVoltage(),3)+" V";
  if(name=="mpu"){ float x,y,z; bool ok=readAccel(x,y,z);
                   return ok?(String(x,2)+"/"+String(y,2)+"/"+String(z,2)):"no i2c"; }
  if(name=="encL")   return String(encLeftTicks);
  if(name=="encR")   return String(encRightTicks);
  if(name=="cliffL") return "not installed tonight";
  if(name=="cliffR") return "not installed -- D10 is PIR now";
  if(name=="rear")   return "not installed tonight";
  if(name=="pir")    return digitalRead(PIN_PIR) ? "MOTION" : "clear";
  if(name=="oled")   return oledOK ? "oled ok" : "oled not found";
  return "unknown module";
}

String set_estop(int on){
  lockState(); estop=(on!=0); unlockState();
  if(on!=0) driveStop();
  return (on!=0)?"estop ON":"estop OFF";
}

// ============================================================================
void setup(){
  pinMode(PIN_STBY,OUTPUT); digitalWrite(PIN_STBY,HIGH);
  pinMode(PIN_PWMA,OUTPUT); pinMode(PIN_AIN1,OUTPUT); pinMode(PIN_AIN2,OUTPUT);
  pinMode(PIN_PWMB,OUTPUT); pinMode(PIN_BIN1,OUTPUT); pinMode(PIN_BIN2,OUTPUT);
  pinMode(PIN_TRIG,OUTPUT); pinMode(PIN_ECHO,INPUT);
  pinMode(PIN_CLIFF_L,INPUT_PULLUP); pinMode(PIN_REAR_IR,INPUT_PULLUP);
  pinMode(PIN_PIR,INPUT);                        // PIR module drives this pin itself, no pull-up needed
  pinMode(PIN_ENC_L,INPUT_PULLUP); pinMode(PIN_ENC_R,INPUT_PULLUP);
  attachInterrupt(digitalPinToInterrupt(PIN_ENC_L), isrEncLeft,  RISING);
  attachInterrupt(digitalPinToInterrupt(PIN_ENC_R), isrEncRight, RISING);

  servoPan.attach(PIN_SERVO_PAN);
  servoTilt.attach(PIN_SERVO_TILT);
  servoPan.write(currentPan);      // center both on boot
  servoTilt.write(currentTilt);

  Wire.begin();
  Wire.beginTransmission(MPU6050_ADDR); Wire.write(0x6B); Wire.write(0x00); Wire.endTransmission();

  // SAFETY: begin() returning false must NEVER halt the MCU. See the big
  // comment at the top of this file for why.
  oledOK = oled.begin(SSD1306_SWITCHCAPVCC, OLED_ADDR);
  if(oledOK){
    oled.clearDisplay();
    oled.setTextSize(1);
    oled.setTextColor(SSD1306_WHITE);
    oled.setCursor(0,0);
    oled.println("== GEPARD V5.0 ==");
    oled.println("booting...");
    oled.display();
  }

  driveStop();

  Bridge.begin();                                     // start Bridge FIRST

  // PURE read-and-return -> background RPC thread is fine:
  Bridge.provide("get_telemetry", get_telemetry);

  // Touch hardware -> MUST run in loop() context:
  Bridge.provide_safe("set_drive",   set_drive);
  Bridge.provide_safe("set_nudge",   set_nudge);
  Bridge.provide_safe("test_module", test_module);
  Bridge.provide_safe("set_estop",   set_estop);
  Bridge.provide_safe("set_pantilt", set_pantilt);
}

void loop(){
  static unsigned long lastSample = 0;
  static unsigned long lastOled   = 0;
  unsigned long now = millis();

  // 1) sample sensors on a cadence (hardware access in safe loop context)
  if(now - lastSample >= SAMPLE_INTERVAL_MS){
    lastSample = now;
    sampleSensors();
  }

  // 2) redraw OLED on its own slower cadence (I2C display writes aren't free)
  if(now - lastOled >= OLED_INTERVAL_MS){
    lastOled = now;
    updateOLED();
  }

  // 3) auto-stop an expired nudge (docking helper)
  lockState();
  bool expire = (nudgeStopAt!=0 && now>=nudgeStopAt);
  if(expire){ nudgeStopAt=0; currentCommand='S'; }
  unlockState();
  if(expire) driveStop();

  delay(2);
}
